#include <iostream>
#include <string>
#include <ctime>
#include<stdlib.h>
#include<windows.h>
#include<iomanip>
#include<vector>

using namespace std;
void Wait(int iTime)
{
	clock_t End;
	End = clock () + iTime;
	while(clock() < End);
}
void AddWord(std::vector<std::string> &vList, std::string sWord)
{
	std::cout << " "" << sWord << " "" << std::endl;
	vList.push_back(sWord);
}
std::string GetWord(std::vector<std::string> vList, unsigned int iIndex)
{
	return vList.at(iIndex);
}
int GetRandom(int iMax)
{
	int iRandom;
	
	Wait(100);
	
	srand(static_cast<unsigned int>(time(NULL) * clock()));
	iRandom = (rand() / (RAND_MAX / iMax + 1));
	
	return iRandom;
}
class game
{
    int tries=7;
    int counter;
    string respnse;
    string shown="";

public:
    void reset();
    void drawing();
    void triesL();
    void store(string hWord);
    void addT();
    void fullMan();
};
void game::triesL()
{
    static int loop=1;
    char letter;
    float sCountr=0;

    for(int i=0; i<(int)respnse.length(); i++)
    {
        if(isalnum(respnse[i]))
        {
            shown=shown+"-";
            sCountr++;
        }
        else
        {
            shown=shown+respnse[i];
        }
    }
    cout<<shown<<endl;

    cout<<"What letter do you think is here?"<<endl;
    cin>>letter;

    for(int b=0; b<(int)respnse.size(); b++)
    {
        if(respnse[b]==letter || toupper(letter)==respnse[b])
        {
            shown[b]=letter;
        }

    }

    cout<<shown<<endl;
    cout<<"You have "<<tries<<" tries left."<<endl;
    while(loop)
    {
        int tracker=0;
        int shownT=0;

        cout<<"What letter do you think is here? or enter (?) to leave"<<endl;
        cin>>letter;

        if(letter=='?')
        {
            break;
        }
        for(int b=0; b<(int)respnse.size(); b++)
        {
            
            if(respnse[b]==letter || toupper(letter)==respnse[b])
            {
                shown[b]=letter;
                tracker=1;
            }
            
            else if(respnse[b]!=letter || respnse[b]!=toupper(letter))
            {
                tracker=tracker+0;
            }
        }

        for(int d=0; d<sCountr; d++)
        {
            if(shown[d]=='-' || shown[d]==' ')
            {
                shownT=1;
            }
            else if(shown[d]!='-')
            {
                shownT=shownT+0;
            }
        }

        
        if(tracker==0)
        {
            addT();
            drawing();
        }

        
        if(shownT==0 || shown==respnse)
        {
            loop=0;
            cout<<"Secret Word: "<<respnse<<endl;
            cout<<"You win."<<endl;
            reset();
        }
        cout<<shown<<endl;

        if(tries>0 && shownT!=0 && shown!=respnse)
        {
            cout<<"You have "<<tries<<" tries left."<<endl;
        }
        if(tries==0)
        {
            loop=0;
            cout<<"You lose."<<endl;
            cout<<"The word was: "<<respnse<<endl;
            cout<<"Try the game again... Thank you"<<endl;
            reset();

            cout<<endl;
            cout<<endl;
        }

    }
}
void game::store(string x)
{
    respnse=x;
}
void game::reset()
{
    respnse="";
    shown="";
    tries=7;
}
void game::addT()
{
    tries--;
}
void game::drawing()
{
    if(tries==6 || tries==7)
    {
        cout << " ___________"<<endl;
        cout << " |        }"<<endl;
        cout << " |         " <<endl;
        cout << "_|______________"<<endl;
    }
    else if(tries==5)
    {
        cout << " ___________"<<endl;
        cout << " |        }"<<endl;
        cout << " |       \\  " <<endl;
        cout << "_|______________"<<endl;
    }
    else if(tries==4)
    {
        cout << " ___________"<<endl;
        cout << " |         }"<<endl;
        cout << " |       \\ 0 " <<endl;
        cout << "_|______________"<<endl;
    }
    else if(tries==3)
    {
        cout << " ___________"<<endl;
        cout << " |         }"<<endl;
        cout << " |       \\ 0 /" <<endl;
        cout << "_|______________"<<endl;
    }
    else if(tries==2)
    {
        cout << " ___________"<<endl;
        cout << " |        }"<<endl;
        cout << " |      \\ 0 /" <<endl;
        cout << " |        |"<<endl;
        cout << "_|______________"<<endl;
    }
    else if(tries==1)
    {
        cout << " ___________"<<endl;
        cout << " |         }"<<endl;
        cout << " |       \\ 0 /"<<endl;
        cout << " |         | "<<endl;
        cout << " |        /  "<<endl;
        cout << "_|______________"<<endl;
    }
    else
    {
        cout << " ___________"<<endl;
        cout << " |         }"<<endl;
        cout << " |       \\ 0 /"<<endl;
        cout << " |         | "<<endl;
        cout << " |        / \\ "<<endl;
        cout << "_|______________"<<endl;
    }
}
int main()
{
    int iSize;
	int iRandom;
	std::string sWord;
	std::vector<std::string> vWords;
	
	std::cout << "Adding 10 words to the list" << std::endl;
	AddWord(vWords, "Book");
	AddWord(vWords, "Wall");
	AddWord(vWords, "Computer");
	AddWord(vWords, "Calculator");
	AddWord(vWords, "Television");
	AddWord(vWords, "Bed");
	AddWord(vWords, "Flower");
	AddWord(vWords, "Chair");
	AddWord(vWords, "Table");
	AddWord(vWords, "Cup");
	
	assert(vWords.size() == 10);
	
	std::cout << std::endl;	
	std::cout << "Generating 5 random words from the list" << std::endl;
	for(unsigned int iIndex = 0; iIndex < 5; iIndex++)
	{
		iSize   = vWords.size();
		iRandom = GetRandom(iSize);
		sWord   = GetWord(vWords, iRandom);
		
		std::cout << " - Returned ... \"" << sWord << "\"" << std::endl;
	}
    game obj;
    int choice;//classes letter the user over and over until they get tired
    int loop=1;//used for the while loop below
    char ans='n';//the original condition of the while loop
    string uWord;// the secret word the user enters
    string topic;// the topic for the hangman game

    while(ans=='n' || ans=='N')
    {
        cout<<"Welcome to a game of hangman."<<endl;
        cout<<"Press any key to continue."<<endl;
        cin>>ans;
        system("");
    }
    while(loop)
    {
        cout<<"********************"<<endl;
        cout<<"1)Select your word *"<<endl;
        cout<<"2)Play game        *"<<endl;
        cout<<"********************"<<endl;
        cout<<"Your choice here >";
        cin>>choice;
        if(choice==1)
        {
            HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
            DWORD mode = 0;
            GetConsoleMode(hStdin, &mode);
            SetConsoleMode(hStdin, mode & (~ENABLE_ECHO_INPUT));
            cout << "Type out the desired word and press enter." << endl;
            cin.ignore();
            getline(cin,uWord);
            SetConsoleMode(hStdin, mode);
            obj.store(uWord);
            cout<<"Your word has been entered."<<endl;
            cout<<endl;
            cout<<endl;
        }

        else (choice==2);
        {
            obj.triesL();
        }

    }

}